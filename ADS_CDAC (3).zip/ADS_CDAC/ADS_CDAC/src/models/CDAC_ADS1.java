package models;
public class CDAC_ADS1 {

	public static void main(String[] args) {
		System.out.println("Hello!");
		Employee e1 = new Employee(1,"Pranav");
		Employee e2 = new Employee(2,"Amit");
		Employee e3 = new Employee(3,"Nihaal");
		Employee e4 = new Employee(4,"Raghav");
		
		GenericSLL<Employee> ls = new GenericSLL<Employee>();
		ls.addAtEnd(e1);
		ls.addAtEnd(e2);
		ls.addAtEnd(e3);
		ls.addAtEnd(e4);
		
		ls.show();
		
		ls.remove(1);
		ls.remove(1);
		
		ls.show();
	}

}
