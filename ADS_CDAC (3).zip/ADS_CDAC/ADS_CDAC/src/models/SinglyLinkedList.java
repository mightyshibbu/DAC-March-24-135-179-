package models;

public class SinglyLinkedList {
Node head;
public SinglyLinkedList(Node head) {
super();
this.head = head;
}
public SinglyLinkedList() {
	super();
	this.head = null;
}
	public class Node{
	int data;
	Node next;
	Node(int data){
		this.data=data;
		this.next=null;
	}
}
public Node addAtEnd(int data) {
	Node newNode=new Node(data);
	if(this.head==null) {
		this.head=newNode;
		return newNode;
	}
	Node temp=this.head;
	Node temp2=this.head;
	while(temp.next!=null) {
		temp=temp.next;
	}
	temp.next=newNode;
	return temp2;
}
public void show() {
	Node head=this.head;
	if(head==null) {
		System.out.println("Empty Singly Linked List!");
		return;
	}
	System.out.print("[");
	do{
		System.out.print(head.data+" -> ");
		head=head.next;
	}while(head!=null) ;
	System.out.print("NULL ]");
	return;
}
}
