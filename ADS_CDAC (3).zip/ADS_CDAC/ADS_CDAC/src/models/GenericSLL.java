package models;

public class GenericSLL <T>{
	Node<T> head;
	public GenericSLL(Node<T> head) {
	super();
	this.head = head;
	}
	public GenericSLL() {
		super();
		this.head = null;
	}
		public class Node<T>{
		T data;
		Node<T> next;
		Node(T data){
			this.data=data;//DOUBT
			this.next=null;
		}
	}
	public Node<T> addAtEnd(T data) {
		Node<T> newNode=new Node<T>(data);
		if(this.head==null) {
			this.head=newNode;
			return newNode;
		}
		Node<T> temp=this.head;
		Node<T> temp2=this.head;
		while(temp.next!=null) {
			temp=temp.next;
		}
		temp.next=newNode;
		return temp2;
	}
	public boolean isNull(){
		if(this.head==null) {
			return true;
		}else return false;
	}
	public boolean hasNext(){
		if(this.head.next==null) {
			return true;
		}else return false;
	}
	public Node<T> remove(int index){
		Node<T> temp = this.head;
		if(this.isNull()) {
			System.out.println("List already empty!");
			return null;
		}else {
			while(--index!=0) {
				this.head=this.head.next;
			}
			head.next=head.next.next;
			return temp;
		}
	}
	
	public void show() {
		Node<T> head=this.head;
		if(head==null) {
			System.out.println("Empty Singly Linked List!");
			return;
		}
		System.out.print("[ \n");
		do{
			System.out.print(head.data.toString()+" -> \n");
			head=head.next;
		}while(head!=null) ;
		System.out.print("NULL \n] \n");
		return;
	}
	

}
