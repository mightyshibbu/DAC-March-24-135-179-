/**
 * 
 */
/**
 * 
 */
module ADS_CDAC {
}